#!/bin/bash
chmod +x /tmp/dop-1.0-SNAPSHOT.jar