#!/bin/bash
aws s3 cp s3://zakir-artifact-repository/builds/dop-1.0-SNAPSHOT.jar /tmp/