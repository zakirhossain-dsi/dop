#!/bin/bash
java -jar /tmp/dop-1.0-SNAPSHOT.jar > /tmp/app.log 2>&1 &